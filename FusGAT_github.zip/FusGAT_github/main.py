
import torch
import torch.nn as nn
import time
import numpy as np
import hues
import os
import random
import scipy.io as sio
from model.config import args
from model.evaluation import MetricsCal
import time
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"


def setup_seed(seed):
   torch.manual_seed(seed)
   torch.cuda.manual_seed_all(seed)
   np.random.seed(seed)
   random.seed(seed)
   torch.backends.cudnn.deterministic = True
setup_seed(61)


from model.srf_psf_layer import Blind
blind = Blind(args)
start = time.perf_counter()
lr_msi_fhsi_est, lr_msi_fmsi_est=blind.train()
blind.get_save_result()
psf = blind.model.psf.data.cpu().detach().numpy()[0,0,:,:]
srf = blind.model.srf.data.cpu().detach().numpy()[:,:,0,0].T
psf_gt=blind.psf_gt
srf_gt=blind.srf_gt
end = time.perf_counter()
elapsed_S1 = end - start

from model.fusgat_1 import fusgat_1
FusGAT = fusgat_1(args, srf,psf)
start = time.perf_counter()
HrHSI = FusGAT.train()
end = time.perf_counter()
elapsed = end - start
print(elapsed)







