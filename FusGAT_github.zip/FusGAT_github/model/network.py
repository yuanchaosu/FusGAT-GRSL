import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.optim import lr_scheduler
import torch.nn.functional as F
import numpy as np
from einops import rearrange
import os
import math
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def get_scheduler(optimizer, opt):
    if opt.lr_policy == 'lambda':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + 1 + opt.epoch_count - opt.niter) / float(opt.niter_decay + 1)
            return lr_l

        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=opt.lr_decay_gamma)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='max',
                                                   factor=opt.lr_decay_gamma,
                                                   patience=opt.lr_decay_patience)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler


def init_weights(net, init_type='normal', gain=0.02):
    def init_func(m):
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=gain)
            elif init_type == 'mean_space':
                batchsize, channel, height, weight = list(m.weight.data.size())
                m.weight.data.fill_(1 / (height * weight))
            elif init_type == 'mean_channel':
                batchsize, channel, height, weight = list(m.weight.data.size())
                m.weight.data.fill_(1 / (channel))
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:
            init.normal_(m.weight.data, 1.0, gain)
            init.constant_(m.bias.data, 0.0)

    print('initialize network with %s' % init_type)
    net.apply(init_func)



def init_net(net, gpu_ids,init_type='normal', init_gain=0.02):
    net.to(gpu_ids)
    init_weights(net, init_type, gain=init_gain)
    return net


class SumToOneLoss(nn.Module):
    def __init__(self):
        super(SumToOneLoss, self).__init__()
        self.register_buffer('one', torch.tensor(1, dtype=torch.float))

        self.loss = nn.L1Loss(size_average=False)

    def get_target_tensor(self, input):
        target_tensor = self.one
        return target_tensor.expand_as(input)

    def __call__(self, input):
        input = torch.sum(input, 1)
        target_tensor = self.get_target_tensor(input)
        # print(input[0,:,:])
        loss = self.loss(input, target_tensor)
        # loss = torch.sum(torch.abs(target_tensor - input))
        return loss


def kl_divergence(p, q):
    p = F.softmax(p,dim=1)
    q = F.softmax(q,dim=1)

    s1 = torch.sum(p * torch.log(p / q))
    s2 = torch.sum((1 - p) * torch.log((1 - p) / (1 - q)))
    return s1 + s2


class SparseKLloss(nn.Module):
    def __init__(self):
        super(SparseKLloss, self).__init__()
        self.register_buffer('zero', torch.tensor(0.01, dtype=torch.float))

    def __call__(self, input):
        input = torch.sum(input, 0, keepdim=True)
        target_zero = self.zero.expand_as(input)
        loss = kl_divergence(target_zero, input)
        return loss









##################################################################################################################

class Msi2Delta(nn.Module):
    def __init__(self,input_ch, output_ch):
        super(Msi2Delta, self).__init__()
        self.relu = nn.LeakyReLU(0.2, True)
        self.conv_input = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=3, stride=1, padding=1,bias=False)
        self.conv_input2 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=5, stride=1, padding=2,bias=False)
        self.softmax = nn.Softmax(dim=1)
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        out1=self.relu(self.conv_input2(x))
        out = self.relu(self.conv_input(x))
        out = self.softmax(out+out1)
        return out


def define_msi2s(input_ch, output_ch, gpu_ids, init_type='kaiming', init_gain=0.02):
    net = Msi2Delta(input_ch, output_ch)
    return init_net(net, gpu_ids, init_type, init_gain)

######################################################################################################

def define_s2img(input_ch, output_ch, gpu_ids, init_type='kaiming', init_gain=0.02):
    net = S2Img(input_c=input_ch, output_c=output_ch)
    return init_net(net, gpu_ids, init_type, init_gain)


class S2Img(nn.Module):
    def __init__(self, input_c, output_c):
        super(S2Img, self).__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels=input_c, out_channels=output_c, kernel_size=1, stride=1, padding=0, bias=False),
            nn.LeakyReLU(0.2, True),
        )

    def forward(self, x):
        return self.net(x)


##############################################################################################################
def define_lr2s(input_ch,output_ch, gpu_ids, init_type='kaiming', init_gain=0.02):

    net = Lr2Delta(input_ch,output_ch)
    return init_net(net, gpu_ids, init_type, init_gain)


class Lr2Delta(nn.Module):
    def __init__(self,input_ch,output_ch):
        super(Lr2Delta, self).__init__()
        self.conv_input = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=1, stride=1, padding=0,bias=False)
        self.conv_input11 = nn.Conv2d(in_channels=output_ch, out_channels=output_ch, kernel_size=1, stride=1, padding=0,bias=False)
        self.conv_input1 = nn.Conv2d(in_channels=output_ch, out_channels=output_ch, kernel_size=3, stride=1, padding=1,bias=False)
        #self.conv_input2 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=5, stride=1, padding=2, bias=False)
        self.softmax = nn.Softmax(dim=1)
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        out = self.relu(self.conv_input(x))
        out1 = self.relu(self.conv_input11(out))
        out2 = self.relu(self.conv_input1(out))
        out = out+out1+out2
        out = self.softmax(out)
        return out
#####################################################################################

def define_lr_Abundance(input_ch,output_ch, gpu_ids, init_type='kaiming', init_gain=0.02, useSoftmax=True):

    net = Lr_Abundance(input_ch,output_ch, useSoftmax=useSoftmax)
    return init_net(net, gpu_ids, init_type, init_gain)


class Lr_Abundance(nn.Module):
    def __init__(self,input_ch,output_ch , useSoftmax=True):
        super(Lr_Abundance, self).__init__()
        self.conv_input1 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=3, stride=1, padding=1,bias=False)
        self.conv_input2 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=5, stride=1, padding=2, bias=False)
        self.BN=nn.BatchNorm2d(output_ch)
        self.softmax = nn.Softmax(dim=1)
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        out = self.relu(self.conv_input1(x))
        out1 = self.relu(self.conv_input2(x))
        out = torch.add(out,out1)
        out = self.softmax(out)
        return out




######################################################################################
def define_lrup_Abundance(input_ch,output_ch, n_h,channel,a,gpu_ids, init_type='kaiming', init_gain=0.02):

    net = Lrup_Abundance(input_ch,output_ch,n_h,channel,a )
    return init_net(net, gpu_ids, init_type, init_gain)


class Lrup_Abundance(nn.Module):
    def __init__(self,input_ch,output_ch,n_h,channel,a):
        super(Lrup_Abundance, self).__init__()

        self.D =Discriminator(n_h,input_ch,output_ch,channel,a)
        self.fus = nn.Conv2d(in_channels=input_ch*1+input_ch, out_channels=output_ch, kernel_size=3, stride=1, padding=1,bias=False)
        self.softmax = nn.Softmax(dim=1)
        self.relu = nn.LeakyReLU(0.2, True)
        self.BN = nn.BatchNorm2d(input_ch)

    def forward(self, x):
        x1=self.D(x)
        out = torch.cat([x,x1],1)
        out = self.relu(self.fus(out))
        out = self.BN(out)
        out = self.softmax(out)
        return out

################################################################################################
def define_edge(input_ch, output_ch,patch,gpu_ids, init_type='kaiming', init_gain=0.02):

    net = getedge(input_ch, output_ch,patch)
    return init_net(net, gpu_ids, init_type, init_gain)


class Patch(nn.Module):
    def __init__(self,input_ch, output_ch,patch):
        super().__init__()
        self.embed = nn.Conv2d(input_ch,output_ch,kernel_size=patch, stride=patch)
        self.relu = nn.LeakyReLU(0.2, True)
    def forward(self, x):
        out = self.relu(self.embed(x))
        return out

class edge(nn.Module):
    def __init__(self):
        super().__init__()
    def forward(self, x):
        b,c,w,h=x.shape
        z = rearrange(x, 'b c w h   ->  (b c) (w h)')
        scores = torch.matmul(z.T, z)
        attn = torch.nn.Softmax(dim=-1)(scores)
        atten_clipped = torch.where(attn < 0.2, torch.zeros_like(attn), torch.clamp(attn, max=1.0))
        return atten_clipped

class getedge(nn.Module):
    def __init__(self,input_ch, output_ch,patch):
        super().__init__()
        self.patch = Patch(input_ch, output_ch,patch)
        self.edge = edge()

    def forward(self, x):
        b,c,h,w = x.shape
        x_petch = self.patch(x)
        edge=self.edge(x_petch)
        return edge

#####################################################################################################################
def define_GrA(patch,input_ch,output_ch,gpu_ids, init_type='kaiming', init_gain=0.02):

    net = GrA(input_ch,output_ch,patch)
    return init_net(net, gpu_ids, init_type, init_gain)

class GrA(nn.Module):
    def __init__(self,input_ch,output_ch,patch):
        super().__init__()
        self.patch = Patch(input_ch,output_ch,patch)
        self.linear = nn.Linear(input_ch, output_ch, bias=False)
        self.attention = nn.Linear(2 * input_ch, 1, bias=False)
        self.decoder = nn.ConvTranspose2d(input_ch, output_ch, kernel_size=patch, stride=patch)
        self.relu = nn.LeakyReLU(0.2, True)

    def forward(self,x,edge):
        b,c,h,w = x.shape
        x_petch = self.patch(x)
        B,C,H,W = x_petch.shape
        x_in = rearrange(x_petch, 'b c w h   ->  (w h) (b c)')
        x_in = self.linear(x_in)
        N = x_in.size()[0]
        a_input = torch.cat([x_in.unsqueeze(1).repeat(1, N, 1), x_in.unsqueeze(0).repeat(N, 1, 1)], dim=2)
        e = self.relu(self.attention(a_input).squeeze(2))
        zero_vec = -1e12 * torch.ones_like(e)
        attention = torch.where(edge > 0, e, zero_vec)
        attention = F.softmax(attention, dim=1)
        out = F.elu(torch.matmul(attention, x_in))
        out = rearrange(out, '(w h) (b c)   -> b c w h ', w=W, h=H, b=B, c=C)
        out = self.relu(self.decoder(out))
        return out

#####################################################################################################################
class Discriminator(nn.Module):
    def __init__(self, n_h,input_ch,output_ch,channel,a):
        super(Discriminator, self).__init__()

        self.Conv3 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=3, stride=1, padding=1,bias=False)
        self.Conv5 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=5, stride=1, padding=2,bias=False)
        self.Conv1 = nn.Conv2d(in_channels=input_ch, out_channels=output_ch, kernel_size=1, stride=1, padding=0,bias=False)
        self.linear = nn.Linear(input_ch, output_ch)
        self.fus = nn.Conv2d(in_channels=input_ch*2, out_channels=output_ch, kernel_size=1, stride=1, padding=0,bias=False)
        self.relu = nn.LeakyReLU(0.2, True)
        self.a=a
        self.linear=nn.Linear(input_ch, output_ch)
        self.soft = nn.Softmax(dim=1)
        self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)


    def forward(self, x):
        x1 = self.relu(self.Conv1(x))
        b,c,w,h=x1.shape
        x3 = self.relu(self.Conv3(x))
        x5 = self.relu(self.Conv5(x))
        xfus = self.relu(self.fus(torch.cat([x3, x5], 1)))
        x1_flatt= rearrange(x1, 'b c w h   -> (b c) (w h)').permute(1,0)
        xfus_flatt=rearrange(xfus, 'b c w h   -> (b c) (w h)').permute(1,0)
        xfus_flatt = self.relu(self.linear(xfus_flatt)).permute(1,0)
        x1_flatt = self.relu(self.linear(x1_flatt)).permute(1,0)
        x_att = torch.nn.functional.softmax(torch.matmul(x1_flatt,x1_flatt.T), dim=-1)
        attn_output = torch.matmul(x_att, xfus_flatt)
        attn_output = rearrange(attn_output, '(b c) (w h) -> b c w h ',b=b, c=c,h=h ,w=w )
        x0 = x1+xfus+attn_output
        return x0


##########################################################################################################################


##########################################################################################################################
def define_psf(scale, gpu_ids, init_type='mean_space', init_gain=0.02):
    net = PSF(scale=scale)
    return init_net(net, gpu_ids, init_type, init_gain)

class PSF(nn.Module):
    def __init__(self, scale):
        super(PSF, self).__init__()
        self.net = nn.Conv2d(1, 1, scale, scale, 0, bias=False)
        self.scale = scale
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        batch, channel, height, weight = list(x.size())
        return torch.cat([self.net(x[:, i, :, :].view(batch, 1, height, weight)) for i in range(channel)], 1)

def define_hr2msi(args, sp_matrix,  gpu_ids, init_type='mean_channel',
                  init_gain=0.02):
    net = matrix_dot_hr2msi(sp_matrix)
    return init_net(net, gpu_ids, init_type, init_gain)


class matrix_dot_hr2msi(nn.Module):
    def __init__(self, spectral_response_matrix):
        super(matrix_dot_hr2msi, self).__init__()
        self.register_buffer('sp_matrix', torch.tensor(spectral_response_matrix.transpose(1, 0)).float())

    def __call__(self, x):
        batch, channel_hsi, heigth, width = list(x.size())
        channel_msi_sp, channel_hsi_sp = list(self.sp_matrix.size())
        hmsi = torch.bmm(self.sp_matrix.expand(batch, -1, -1),
                         torch.reshape(x, (batch, channel_hsi, heigth * width))).view(batch, channel_msi_sp, heigth,
                                                                                      width)
        return hmsi

