# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 19:38:23 2021

@author: 13572
"""
import torch
from torch.nn import init
import torch.nn as nn
import numpy as np
from .evaluation import MetricsCal
from torch.optim import lr_scheduler
import torch.optim as optim
import os
import scipy
from .dataset import Dataset
from . import network
import torch.nn.functional as F
#from.network_s2 import def_two_stream_split


class fusgat_1(Dataset):
    def __init__(self,args,psf,srf):
        super().__init__(args)
        self.args=args
        self.hs_band=self.tensor_lr_hsi.shape[1]
        self.ms_band=self.tensor_hr_msi.shape[1]
        self.h=self.tensor_hr_msi.shape[2]
        self.srf=srf
        self.lr_hsi=self.tensor_lr_hsi
        self.hr_msi=self.tensor_hr_msi
        self.gt=self.tensor_gt
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch +  1 - self.args.niter) / float(self.args.niter_decay + 1)
            return lr_l

        # net generate abundance (encoder for msi)
        self.net_MSI2S = network.define_msi2s(input_ch=self.ms_band, output_ch=self.args.num_s,gpu_ids=self.args.device)
        self.net_s2img = network.define_s2img(input_ch=self.args.num_s, output_ch=self.hs_band, gpu_ids=self.args.device)
        self.net_GrA = network.define_GrA(patch=self.args.patch,input_ch=self.args.num_s, output_ch=self.args.num_s, gpu_ids=self.args.device)
        # encoder for hsi
        self.net_LR2s = network.define_lr2s(input_ch=self.hs_band ,output_ch=self.args.num_s, gpu_ids=self.args.device)
        self.net_lrup_Abundance = network.define_lrup_Abundance(input_ch=self.args.num_s ,output_ch=self.args.num_s,n_h=self.h,channel=self.args.num_s,a=self.args.a ,gpu_ids=self.args.device)
        self.net_edge = network.define_edge(input_ch=self.args.num_s, output_ch=self.args.num_s,patch=self.args.patch, gpu_ids=self.args.device)
        # define psf function
        self.net_PSF = network.define_psf(scale=args.scale_factor,gpu_ids=self.args.device)
        # reconstruct msi image from target HRHSI image
        self.net_G_HR2MSI = network.define_hr2msi(args=self.args,
                                                    sp_matrix=self.srf,
                                                    gpu_ids=self.args.device)
        self.criterionSumToOne = network.SumToOneLoss().to(self.args.device)
        self.criterionSparse = network.SparseKLloss().to(self.args.device)
        self.criterionPixelwise = nn.L1Loss(reduction='mean')

        params1 = []
        params1 += list(self.net_MSI2S.parameters())
        params1 += list(self.net_s2img.parameters())
        params1 += list(self.net_LR2s.parameters())
        params1 += list(self.net_lrup_Abundance.parameters())
        params2 = []
        params2 += list(self.net_GrA.parameters())
        params2 += list(self.net_edge.parameters())
        params2 += list(self.net_PSF.parameters())
        params2 += list(self.net_G_HR2MSI.parameters())
        self.optimizer1 = optim.Adam(params1, lr=self.args.lr)
        self.optimizer2 = optim.Adam(params2, lr=self.args.lr*0.2)
        self.scheduler1=lr_scheduler.LambdaLR(self.optimizer1, lr_lambda=lambda_rule)
        self.scheduler2 = lr_scheduler.LambdaLR(self.optimizer2, lr_lambda=lambda_rule)

    def train(self):

        for epoch in range(1, self.args.niter + self.args.niter_decay + 1):
            self.optimizer1.zero_grad()
            self.optimizer2.zero_grad()
            self.rec_lr_s = self.net_LR2s(self.lr_hsi)
            self.rec_lr_lr = self.net_s2img(self.rec_lr_s)
            # lrup process
            self.lrhsi_up = F.interpolate(self.lr_hsi, scale_factor=self.args.scale_factor, mode='bilinear')
            self.rec_lrup_s = self.net_LR2s(self.lrhsi_up)
            self.edge = self.net_edge(self.rec_lrup_s)

            self.rec_msi_s = self.net_MSI2S(self.hr_msi)
            self.GAT = self.net_GrA(self.rec_msi_s, self.edge)
            self.msi_abundance = self.net_lrup_Abundance(self.rec_msi_s + self.rec_lrup_s+self.GAT)
            self.rec_msi_hr = self.net_s2img(self.msi_abundance)

            self.rec_msi_msi = self.net_G_HR2MSI(self.rec_msi_hr)
            self.rec_msi_lrs = self.net_PSF(self.rec_msi_hr)

            self.loss_lr_s_sumtoone = self.criterionSumToOne(self.rec_lr_s) * self.args.lambda_D
            self.loss_lr_sparse = self.criterionSparse(self.rec_lr_s) * self.args.lambda_F

            self.loss_msi_s_sumtoone = self.criterionSumToOne(self.msi_abundance) * self.args.lambda_D
            self.loss_msi_sparse = self.criterionSparse(self.msi_abundance) * self.args.lambda_F

            self.loss_msi_s_sumtoone = self.criterionSumToOne(self.rec_lrup_s) * self.args.lambda_D
            self.loss_msi_sparse = self.criterionSparse(self.rec_lrup_s) * self.args.lambda_F

            self.loss_S2one = self.loss_lr_s_sumtoone + self.loss_msi_s_sumtoone + self.loss_msi_s_sumtoone
            self.loss_Sp = self.loss_lr_sparse + self.loss_msi_sparse + self.loss_msi_sparse

            self.loss_lr_pixelwise = self.criterionPixelwise(self.lr_hsi, self.rec_lr_lr) * self.args.lambda_A

            self.loss_msi_pixelwise = self.criterionPixelwise(self.hr_msi, self.rec_msi_msi) * self.args.lambda_B
            self.loss_msi_ss_lr = self.criterionPixelwise(self.lr_hsi, self.rec_msi_lrs) * self.args.lambda_B
            self.loss_rec = self.loss_lr_pixelwise
            self.loss_dg = self.loss_msi_pixelwise + self.loss_msi_ss_lr
            loss=self.loss_S2one + self.loss_Sp + self.loss_rec + self.loss_dg
            loss.backward()
           
            self.optimizer1.step()
            self.scheduler1.step()
            self.optimizer2.step()
            self.scheduler2.step()
           
            if epoch % self.args.freq ==0:

                with torch.no_grad():
                    
                    print("____________________________________________")
                    print('epoch:{} lr1:{} lr2:{} 保存结果'.format(epoch,self.optimizer1.param_groups[0]['lr'],self.optimizer1.param_groups[0]['lr']))
                    print('************')

                    hrhsi_est_numpy = self.rec_msi_hr.data.cpu().detach().numpy()[0].transpose(1, 2, 0)
                    gt_numpy=self.gt.data.cpu().detach().numpy()[0].transpose(1, 2, 0)


                    sam, psnr, ergas, cc, rmse, Ssim, Uqi = MetricsCal(gt_numpy, hrhsi_est_numpy, self.args.scale_factor)
                    L1 = np.mean(np.abs(gt_numpy - hrhsi_est_numpy))
                    metr = "precision:\n L1 {} sam {},psnr {},ergas {},cc {},rmse {},Ssim {},Uqi {}".format(
                        L1, sam, psnr, ergas, cc, rmse, Ssim, Uqi)
                    print(metr)
                    print('************')

                    file_name = os.path.join(self.args.expr_dir, 'precision.txt')
                    with open(file_name, 'a') as opt_file:
                        opt_file.write('epoch:{}'.format(epoch))
                        opt_file.write('\n')
                        opt_file.write(metr)
                        opt_file.write('\n')
                        opt_file.write('\n')

                scipy.io.savemat(os.path.join(self.args.expr_dir, 'Out.mat'),
                                 {'Out': self.rec_msi_hr.data.cpu().numpy()[0].transpose(1, 2, 0)})

        return self.rec_msi_hr.data.cpu().numpy()[0].transpose(1, 2, 0)

if __name__ == "__main__":
    pass